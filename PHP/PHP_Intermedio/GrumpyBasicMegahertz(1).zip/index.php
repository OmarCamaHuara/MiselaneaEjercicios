<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <h1> Aula 1 - Arrays</h1>
    <hr>
    <a href="aula1.php">Aula 1</a>
    <br><br><br>
     <hr>
    <h1> Aula 2 - Funções Recursivas (Link)</h1>
    <hr>
    <a href="aula2.php">Aula 2</a>
     <br><br><br>
     <hr>
    <h1> Aula 3 - JSON</h1>
    <hr>
    <a href="aula3.php">Aula 3</a>
 <br><br><br>
     <hr>
    <h1> Aula 3 - JSON</h1>
    <hr>
    <a href="aula4.php">Aula 4</a>
    
  </body>
</html>